from PIL import Image, ImageFilter

img = Image.open('./Pokedex/astro.jpg')
img.thumbnail((400, 400))
img.save('thumbnail.jpeg')
img.save("astro.jpg", 'png')

