from PIL import Image, ImageFilter

img = Image.open('./Pokedex/pikachu.jpg')


resize = img.resize((770, 498))

# print(img.format)
# print(img.size)
# print(dir(img))
# filtered_img = img.filter(ImageFilter.BLUR)
# filtered_img = img.filter(ImageFilter.SMOOTH)
# filtered_img = img.filter(ImageFilter.SHARPEN)
filtered_img = img.convert('L')
# crooked = filtered_img.rotate(180)
box = (100, 100, 400, 400)
region = filtered_img.crop(box)
# resize = filtered_img.resize((300, 300))
region.save("grey.png", 'png')
