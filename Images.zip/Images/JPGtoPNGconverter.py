import sys
import os
from PIL import Image

# add directory to variable
path = r'C:\Users\fuadd\PycharmProjects\Images\Pokedex'
directory = r"C:\Users\fuadd\PycharmProjects\Images\new"

if not os.path.exists(directory):
    os.mkdir(directory)

for filename in os.listdir(path):
    img = Image.open(f"{path}/{filename}")
    img_split = os.path.splitext(filename)[0]
    img.save(f'{directory}/{img_split}.png', 'png')